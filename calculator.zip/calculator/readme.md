# mwu-계산기앱 만들기 with 프로그래머스

## 2023-05-11 
- [x] 기본 UI 완성
- [x] data-* 요소 삽입
- [x] calculator class 만들기
- [x] constructor 만들기
- [x] 숫자 버튼 기능 구현 
- [x] onPressNumber 만들기
- [x] 사칙연산 버튼 기능 구현
- [x] appendOperation 만들기
- [x] onEuqal 기능 만들기
- [x] reset 기능 구현
- [x] delete 기능 구현